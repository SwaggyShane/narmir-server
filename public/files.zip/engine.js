// src/game/engine.js
// Pure game logic — no I/O, no socket calls.
// All functions take a kingdom row (or rows) and return mutations + events.

const RACE_BONUSES = {
  high_elf:  { research: 1.15, magic: 1.20 },
  dwarf:     { construction: 1.20, war_machines: 1.25 },
  dire_wolf: { military: 1.25, research: 0.80 },
  dark_elf:  { covert: 1.20, stealth: 1.20 },
  human:     {},
  orc:       { military: 1.20, economy: 0.90 },
};

const UNIT_COST = 250; // GC per unit, all types
const MAX_RESEARCHERS = 1_000_000;
const MAX_RESEARCH = 1000; // percent cap for most disciplines

// ── Helpers ──────────────────────────────────────────────────────────────────

function raceBonus(kingdom, stat) {
  const bonuses = RACE_BONUSES[kingdom.race] || {};
  return bonuses[stat] || 1.0;
}

function goldPerTurn(k) {
  const baseRate = Math.floor(k.land * (k.tax / 100) * (k.res_economy / 100));
  const marketBonus = Math.floor(k.bld_markets / 30) * 200;
  const castleBonus = Math.floor(k.bld_castles / 500) * 500;
  const econBonus = raceBonus(k, 'economy');
  return Math.floor((baseRate + marketBonus + castleBonus) * econBonus);
}

function manaPerTurn(k) {
  return Math.floor(10 + (k.bld_cathedrals / 25) * 50);
}

function foodBalance(k) {
  const totalTroops = k.fighters + k.rangers + k.clerics + k.mages +
                      k.thieves + k.ninjas + k.researchers + k.engineers;
  const production = Math.floor(k.bld_farms / 10) * 100;
  const consumption = totalTroops + Math.floor(k.population / 50);
  return production - consumption;
}

function popGrowth(k) {
  if (k.morale < 30) return -Math.floor(k.population * 0.02);
  const base = Math.floor(k.population * 0.003);
  const entertainment = Math.floor(k.res_entertainment / 100) * 10;
  const colosseumBonus = Math.floor(k.bld_colosseums / 25) * 50;
  return base + entertainment + colosseumBonus;
}

function researchIncrement(k, discipline, researchersAssigned) {
  const schoolBonus = 1 + (Math.floor(k.bld_schools / 5) * 0.02);
  const raceMulti = discipline === 'spellbook' ? raceBonus(k, 'magic') : raceBonus(k, 'research');
  const effective = Math.floor(researchersAssigned * schoolBonus * raceMulti);
  if (effective >= 2000) return 5;
  if (effective >= 1200) return 3;
  if (effective >= 600)  return 2;
  if (effective >= 200)  return 1;
  return 0;
}

// ── Turn processor ────────────────────────────────────────────────────────────

function processTurn(k) {
  const events = [];
  const updates = { turn: k.turn + 1, updated_at: Math.floor(Date.now() / 1000) };

  // Gold income
  const income = goldPerTurn(k);
  updates.gold = k.gold + income;
  events.push({ type: 'system', message: `Turn ${updates.turn}: +${income.toLocaleString()} GC earned. Treasury: ${updates.gold.toLocaleString()} GC.` });

  // Mana regeneration
  const manaGain = manaPerTurn(k);
  updates.mana = k.mana + manaGain;

  // Population growth
  const growth = popGrowth(k);
  updates.population = Math.max(0, k.population + growth);

  // Food check
  const food = foodBalance(k);
  updates.food = food;
  if (food < 0) {
    // Troops starve proportionally
    const starvePct = Math.min(0.1, Math.abs(food) / (k.fighters + k.rangers + 1) * 0.01);
    updates.fighters  = Math.max(0, Math.floor(k.fighters  * (1 - starvePct)));
    updates.rangers   = Math.max(0, Math.floor(k.rangers   * (1 - starvePct)));
    events.push({ type: 'system', message: `Food shortage! Troops are starving — ${Math.floor(starvePct * 100)}% losses across military.` });
  }

  // Morale decay from high tax
  if (k.tax > 50) {
    const penalty = Math.floor((k.tax - 50) * 0.5);
    updates.morale = Math.max(0, k.morale - penalty);
    events.push({ type: 'system', message: `High taxation (${k.tax}%) reduced morale by ${penalty}.` });
  } else if (k.morale < 100) {
    updates.morale = Math.min(200, k.morale + 1);
  }

  // Training fields auto-advance military tactics
  if (k.bld_training > 0) {
    const trainingGain = Math.floor(k.bld_training / 50);
    if (trainingGain > 0) {
      updates.res_military = Math.min(MAX_RESEARCH, k.res_military + trainingGain);
    }
  }

  updates.last_turn_at = Math.floor(Date.now() / 1000);
  return { updates, events };
}

// ── Hire units ────────────────────────────────────────────────────────────────

function hireUnits(k, unit, amount) {
  const validUnits = ['fighters','rangers','clerics','mages','thieves','ninjas','researchers','engineers'];
  if (!validUnits.includes(unit)) return { error: 'Invalid unit type' };
  if (amount <= 0) return { error: 'Amount must be positive' };
  if (unit === 'researchers' && (k.researchers + amount) > MAX_RESEARCHERS) {
    return { error: `Max researchers is ${MAX_RESEARCHERS.toLocaleString()}` };
  }

  const cost = amount * UNIT_COST;
  if (k.gold < cost) return { error: `Not enough gold — need ${cost.toLocaleString()} GC` };
  if (amount > k.population) return { error: 'Not enough population available' };

  return {
    updates: {
      gold: k.gold - cost,
      population: k.population - amount,
      [unit]: k[unit] + amount,
      updated_at: Math.floor(Date.now() / 1000),
    }
  };
}

// ── Research ──────────────────────────────────────────────────────────────────

const RESEARCH_MAP = {
  economy:      'res_economy',
  weapons:      'res_weapons',
  armor:        'res_armor',
  military:     'res_military',
  spellbook:    'res_spellbook',
  attack_magic: 'res_attack_magic',
  defense_magic:'res_defense_magic',
  entertainment:'res_entertainment',
  construction: 'res_construction',
  war_machines: 'res_war_machines',
};

function studyDiscipline(k, discipline, researchersAssigned) {
  const col = RESEARCH_MAP[discipline];
  if (!col) return { error: 'Unknown discipline' };
  if (researchersAssigned > k.researchers) return { error: 'Not enough researchers' };

  const increment = researchIncrement(k, discipline, researchersAssigned);
  if (increment === 0) return { error: 'Need more researchers for any progress (min ~200)' };

  const cap = discipline === 'spellbook' ? Infinity : MAX_RESEARCH;
  const newVal = Math.min(cap, k[col] + increment);

  return {
    updates: { [col]: newVal, updated_at: Math.floor(Date.now() / 1000) },
    increment,
  };
}

// ── Construction ──────────────────────────────────────────────────────────────

const BUILDING_PIECES = {
  farms: 10, barracks: 2, outposts: 2, guard_towers: 2,
  schools: 5, armories: 5, vaults: 5, smithies: 15,
  markets: 30, cathedrals: 25, training: 50, colosseums: 25, castles: 500,
};

const BUILDING_COL = {
  farms: 'bld_farms', barracks: 'bld_barracks', outposts: 'bld_outposts',
  guard_towers: 'bld_guard_towers', schools: 'bld_schools', armories: 'bld_armories',
  vaults: 'bld_vaults', smithies: 'bld_smithies', markets: 'bld_markets',
  cathedrals: 'bld_cathedrals', training: 'bld_training', colosseums: 'bld_colosseums',
  castles: 'bld_castles',
};

function buildStructure(k, building, quantity) {
  const piecesPerUnit = BUILDING_PIECES[building];
  const col = BUILDING_COL[building];
  if (!piecesPerUnit || !col) return { error: 'Unknown building type' };
  if (quantity <= 0) return { error: 'Quantity must be positive' };

  const piecesNeeded = quantity * piecesPerUnit;
  const constrBonus = 1 + (k.bld_smithies / 15) * 0.02 * raceBonus(k, 'construction');
  const maxBuildable = Math.floor(k.engineers * constrBonus);

  if (piecesNeeded > maxBuildable) {
    return { error: `Need ${piecesNeeded.toLocaleString()} engineer-turns but only ${maxBuildable.toLocaleString()} available` };
  }

  return {
    updates: {
      [col]: k[col] + quantity,
      updated_at: Math.floor(Date.now() / 1000),
    },
    piecesUsed: piecesNeeded,
  };
}

// ── Military combat ───────────────────────────────────────────────────────────

function resolveMilitaryAttack(attacker, defender, fightersSent, magesSent) {
  if (fightersSent > attacker.fighters) return { error: 'Not enough fighters' };
  if (magesSent > attacker.mages)       return { error: 'Not enough mages' };

  // Attack power
  const atkWeapon  = attacker.res_weapons / 100;
  const atkTactics = attacker.res_military / 100;
  const atkRace    = raceBonus(attacker, 'military');
  const atkPower   = (fightersSent * atkWeapon * atkTactics * atkRace)
                   + (magesSent * 2.5 * (attacker.res_attack_magic / 100));

  // Defence power
  const defArmor   = defender.res_armor / 100;
  const defTactics = defender.res_military / 100;
  const defPower   = (defender.fighters * defArmor * defTactics)
                   + (defender.mages * 1.5)
                   + (Math.floor(defender.bld_guard_towers / 2) * 200)
                   + (Math.floor(defender.bld_castles / 500) * 5000);

  // Cleric survival bonus
  const clericSave = 1 - Math.min(0.3, attacker.clerics / (fightersSent + 1) * 0.05);

  // Random variance ±20%
  const variance = 0.8 + Math.random() * 0.4;
  const win = (atkPower * variance) > defPower;

  // Casualties
  const atkLossPct  = win ? (0.04 + Math.random() * 0.08) : (0.20 + Math.random() * 0.25);
  const defLossPct  = win ? (0.15 + Math.random() * 0.20) : (0.05 + Math.random() * 0.08);

  const atkFightersLost = Math.floor(fightersSent * atkLossPct * clericSave);
  const atkMagesLost    = Math.floor(magesSent    * atkLossPct * 0.5);
  const defFightersLost = Math.floor(defender.fighters * defLossPct);
  const landTransferred = win ? Math.floor(defender.land * 0.10) : 0;

  const attackerUpdates = {
    fighters: attacker.fighters - atkFightersLost,
    mages:    attacker.mages    - atkMagesLost,
    land:     attacker.land + landTransferred,
    updated_at: Math.floor(Date.now() / 1000),
  };
  const defenderUpdates = {
    fighters: defender.fighters - defFightersLost,
    land:     defender.land     - landTransferred,
    updated_at: Math.floor(Date.now() / 1000),
  };

  const report = {
    win,
    fightersSent, magesSent,
    atkFightersLost, atkMagesLost,
    defFightersLost, landTransferred,
  };

  const atkEvent = win
    ? `You attacked ${defender.name} and won! Captured ${landTransferred} acres. Lost ${atkFightersLost} fighters.`
    : `Attack on ${defender.name} was repelled. Lost ${atkFightersLost} fighters.`;

  const defEvent = win
    ? `${attacker.name} attacked your kingdom and broke through! Lost ${landTransferred} acres and ${defFightersLost} fighters.`
    : `${attacker.name} attacked but was repelled. You lost ${defFightersLost} fighters defending.`;

  return { win, report, attackerUpdates, defenderUpdates, atkEvent, defEvent };
}

// ── Magic ─────────────────────────────────────────────────────────────────────

const SPELL_DEFS = {
  fire:       { minSB: 200,  effect: 'buildings', damageType: 'warm' },
  rain:       { minSB: 300,  effect: 'buildings', damageType: 'cool' },
  lightning:  { minSB: 500,  effect: 'troops',    damageType: 'strike' },
  amnesia:    { minSB: 800,  effect: 'research',  damageType: 'mental' },
  plague:     { minSB: 1000, effect: 'population',damageType: 'disease' },
  dispel:     { minSB: 400,  effect: 'friendly',  damageType: 'none' },
  bless:      { minSB: 600,  effect: 'friendly',  damageType: 'none' },
  earthquake: { minSB: 1200, effect: 'buildings', damageType: 'force' },
  shield:     { minSB: 1500, effect: 'friendly',  damageType: 'none' },
};

function castSpell(caster, target, spellId, power, duration, obscure) {
  const def = SPELL_DEFS[spellId];
  if (!def) return { error: 'Unknown spell' };
  if (caster.res_spellbook < def.minSB) {
    return { error: `Spellbook too low — need ${def.minSB}, have ${caster.res_spellbook}` };
  }

  const obscureCost = obscure ? Math.floor(power * 0.5) : 0;
  const totalMana   = power + obscureCost;

  if (caster.mana < totalMana) {
    return { error: `Not enough mana — need ${totalMana.toLocaleString()}, have ${caster.mana.toLocaleString()}` };
  }

  // Spellbook degrades slightly each cast
  const sbDecay = Math.floor(power * 0.001);
  const casterUpdates = {
    mana: caster.mana - totalMana,
    res_spellbook: Math.max(0, caster.res_spellbook - sbDecay),
    updated_at: Math.floor(Date.now() / 1000),
  };

  // Power per turn spread over duration
  const powerPerTurn = Math.floor(power / duration);
  const atkMagic = caster.res_attack_magic / 100;
  const defMagic = target.res_defense_magic / 100;
  const effectivePower = Math.floor(powerPerTurn * atkMagic / Math.max(0.5, defMagic));

  // Friendly spells
  if (def.effect === 'friendly') {
    const targetUpdates = {};
    if (spellId === 'bless')  { targetUpdates.morale = Math.min(200, target.morale + Math.floor(effectivePower / 100)); }
    if (spellId === 'dispel') { /* clears active debuffs — tracked server-side in real impl */ }
    return {
      casterUpdates,
      targetUpdates,
      report: { spellId, obscure, power, duration, effectivePower, win: true },
      targetEvent: `${obscure ? 'An unknown caster' : caster.name} cast ${spellId} on your kingdom.`,
    };
  }

  // Offensive spells — compute damage
  const targetUpdates = {};
  let damageDesc = '';

  if (def.effect === 'buildings') {
    const farmsLost = Math.min(target.bld_farms, Math.floor(effectivePower / 500));
    targetUpdates.bld_farms = target.bld_farms - farmsLost;
    damageDesc = `${farmsLost} farms destroyed`;
  } else if (def.effect === 'troops') {
    const fightersLost = Math.min(target.fighters, Math.floor(effectivePower / 10));
    targetUpdates.fighters = target.fighters - fightersLost;
    damageDesc = `${fightersLost.toLocaleString()} fighters struck down`;
  } else if (def.effect === 'research') {
    const resLost = Math.floor(effectivePower / 200);
    targetUpdates.res_economy = Math.max(0, target.res_economy - resLost);
    damageDesc = `${resLost}% economy research wiped`;
  } else if (def.effect === 'population') {
    const popLost = Math.floor(target.population * (effectivePower / 1_000_000));
    targetUpdates.population = Math.max(0, target.population - popLost);
    damageDesc = `${popLost.toLocaleString()} citizens perished`;
  }

  targetUpdates.updated_at = Math.floor(Date.now() / 1000);

  const targetEventSource = obscure ? 'An unknown caster' : caster.name;
  const targetEvent = obscure
    ? `A mysterious ${spellId} spell struck your kingdom — ${damageDesc}.`
    : `${caster.name} cast ${spellId} on your kingdom — ${damageDesc}.`;

  return {
    casterUpdates,
    targetUpdates,
    report: { spellId, obscure, power, duration, effectivePower, damageDesc, win: true },
    casterEvent: `You cast ${spellId} on ${target.name}. Effect: ${damageDesc}.`,
    targetEvent,
  };
}

// ── Covert ops ────────────────────────────────────────────────────────────────

function covertSpy(spy, target, unitsSent) {
  const stealthMulti = raceBonus(spy, 'stealth');
  const success = (spy.thieves + spy.ninjas) * stealthMulti > target.fighters * 0.02 + target.bld_guard_towers * 5;

  if (!success) {
    const caught = Math.floor(unitsSent * 0.3);
    return {
      success: false,
      spyUpdates:    { thieves: spy.thieves - caught, updated_at: Math.floor(Date.now() / 1000) },
      targetUpdates: {},
      spyEvent:      `Spy mission on ${target.name} failed — ${caught} thieves caught and exposed your location.`,
      targetEvent:   `${spy.name} attempted to spy on you — caught ${caught} thieves.`,
    };
  }

  // Approximate report with ±15% noise
  function noise(n) { return Math.floor(n * (0.85 + Math.random() * 0.30)); }
  const report = {
    name: target.name, race: target.race,
    land: noise(target.land), fighters: noise(target.fighters),
    mages: noise(target.mages), gold: noise(target.gold),
  };

  return {
    success: true, report,
    spyUpdates: {},
    targetUpdates: {},
    spyEvent: `Spy report on ${target.name} retrieved successfully.`,
    targetEvent: null,
  };
}

function covertLoot(thief, target, lootType, thievesSent) {
  if (thievesSent > thief.thieves) return { error: 'Not enough thieves' };
  const stealthMulti = raceBonus(thief, 'stealth');
  const success = thief.thieves * stealthMulti > target.fighters * 0.015 + target.bld_guard_towers * 3
                                                                          + target.bld_armories * 10
                                                                          + target.bld_vaults * 10;

  if (!success) {
    return {
      success: false,
      thiefUpdates:  { thieves: thief.thieves - Math.floor(thievesSent * 0.25), updated_at: Math.floor(Date.now() / 1000) },
      targetUpdates: {},
      event: `Loot attempt on ${target.name} failed. Thieves captured and location revealed.`,
    };
  }

  const targetUpdates = { updated_at: Math.floor(Date.now() / 1000) };
  let stolen = 0, desc = '';

  if (lootType === 'gold') {
    stolen = Math.floor(thievesSent * (50 + Math.random() * 50));
    stolen = Math.min(stolen, Math.floor(target.gold * 0.05));
    targetUpdates.gold = target.gold - stolen;
    desc = `${stolen.toLocaleString()} GC`;
  } else if (lootType === 'research') {
    stolen = Math.floor(thievesSent * 0.2);
    targetUpdates.res_economy = Math.max(0, target.res_economy - stolen);
    desc = `${stolen} economy research points`;
  } else if (lootType === 'weapons') {
    stolen = Math.floor(thievesSent * 0.3);
    targetUpdates.res_weapons = Math.max(0, target.res_weapons - stolen);
    desc = `${stolen} weapon research points`;
  } else if (lootType === 'war_machines') {
    stolen = Math.floor(thievesSent * 0.01);
    targetUpdates.war_machines = Math.max(0, target.war_machines - stolen);
    desc = `${stolen} war machine(s)`;
  }

  return {
    success: true, stolen, lootType,
    thiefUpdates: {},
    targetUpdates,
    thiefEvent:  `Looted ${desc} from ${target.name}.`,
    targetEvent: `Thieves infiltrated your kingdom and stole ${desc}.`,
  };
}

function covertAssassinate(assassin, target, ninjasSent, unitType) {
  if (ninjasSent > assassin.ninjas) return { error: 'Not enough ninjas' };
  const stealthMulti = raceBonus(assassin, 'stealth');
  const success = assassin.ninjas * stealthMulti * 1.2 > target[unitType] * 0.01 + target.bld_guard_towers * 2;

  if (!success) {
    return {
      success: false,
      assassinUpdates: { ninjas: assassin.ninjas - Math.floor(ninjasSent * 0.2), updated_at: Math.floor(Date.now() / 1000) },
      targetUpdates: {},
      event: `Assassination of ${unitType} in ${target.name} failed. Ninjas compromised.`,
    };
  }

  const killed = Math.floor(ninjasSent * (10 + Math.random() * 10));
  const targetUpdates = {
    [unitType]: Math.max(0, target[unitType] - killed),
    updated_at: Math.floor(Date.now() / 1000),
  };

  return {
    success: true, killed,
    assassinUpdates: {},
    targetUpdates,
    assassinEvent: `Assassinated ${killed.toLocaleString()} ${unitType} in ${target.name}.`,
    targetEvent:   `${assassin.name}'s ninjas assassinated ${killed.toLocaleString()} of your ${unitType}.`,
  };
}

// ── Alliance pledge defence ───────────────────────────────────────────────────

function resolveAllianceDefence(attackResult, allies) {
  // When a kingdom is attacked, allied kingdoms send pledge % of their fighters
  if (!attackResult.win) return [];
  return allies.map(ally => {
    const sent = Math.floor(ally.fighters * (ally.pledge / 100));
    return { allyId: ally.id, sent };
  });
}

module.exports = {
  goldPerTurn, manaPerTurn, foodBalance, popGrowth,
  processTurn, hireUnits, studyDiscipline, buildStructure,
  resolveMilitaryAttack, castSpell,
  covertSpy, covertLoot, covertAssassinate,
  resolveAllianceDefence,
  RACE_BONUSES, UNIT_COST, BUILDING_PIECES, BUILDING_COL, SPELL_DEFS,
};
